using ConnectFourSpel.DAL;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// === 1??  Initiera DAL (om du anv�nder Db.Open()) ===
Db.Configure(builder.Configuration);

// === 2??  L�gg till MVC, Sessions och Cookies ===
builder.Services.AddControllersWithViews();

// Session kr�ver cache
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.Cookie.HttpOnly = true;          // skyddar mot JS-access
    options.Cookie.IsEssential = true;       // kr�vs f�r att fungera utan cookie consent
    options.IdleTimeout = TimeSpan.FromHours(8); // hur l�nge sessionen lever
});

// Cookie-autentisering f�r LoginController / [Authorize]
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Login/Login";      // om anv�ndaren inte �r inloggad
        options.LogoutPath = "/Login/Logout";
        options.AccessDeniedPath = "/Login/Login";
        options.SlidingExpiration = true;
        options.ExpireTimeSpan = TimeSpan.FromDays(7);
    });

builder.Services.AddAuthorization();

// === 3??  Skapa app ===
var app = builder.Build();

// === 4??  Middleware-pipeline ===
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Viktigt: ordning spelar roll
app.UseAuthentication();    // cookies
app.UseAuthorization();
app.UseSession();           // sessioner f�r spelet

// === 5??  Routing ===
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run();
