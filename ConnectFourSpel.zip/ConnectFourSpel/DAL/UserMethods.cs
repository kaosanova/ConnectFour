﻿using System.Data.SqlClient;

namespace ConnectFourSpel.DAL
{
    public static class UserMethods
    {
        public static UserDetails? GetByUsername(string username)
        {
            using var conn = Db.Open();
            using var cmd = new SqlCommand(
                "SELECT Id, Username, PasswordHash, CreatedAt FROM tbl_Users WHERE Username=@u;",
                conn);
            cmd.Parameters.AddWithValue("@u", username);

            using var r = cmd.ExecuteReader();
            if (!r.Read()) return null;

            return new UserDetails
            {
                Id = (int)r["Id"],
                Username = (string)r["Username"],
                PasswordHash = (string)r["PasswordHash"],
                CreatedAt = (DateTime)r["CreatedAt"]
            };
        }

        public static int Create(string username, string passwordHash)
        {
            using var conn = Db.Open();
            using var cmd = new SqlCommand(@"
INSERT INTO tbl_Users (Username, PasswordHash, CreatedAt)
OUTPUT INSERTED.Id
VALUES (@u, @p, SYSUTCDATETIME());", conn);
            cmd.Parameters.AddWithValue("@u", username);
            cmd.Parameters.AddWithValue("@p", passwordHash);

            return (int)cmd.ExecuteScalar();
        }
    }
}
