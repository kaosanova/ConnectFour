﻿using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace ConnectFourSpel.DAL
{
    public static class Db
    {
        private static IConfiguration? _config;

        public static void Configure(IConfiguration config) => _config = config;

        public static SqlConnection Open()
        {
            if (_config == null)
                throw new InvalidOperationException("Db.Configure() måste anropas i Program.cs");

            var conn = new SqlConnection(_config.GetConnectionString("Default"));
            conn.Open();
            return conn;
        }
    }
}